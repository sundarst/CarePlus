package careplus.zsgs.manageDoctor;

import java.util.List;

import careplus.zsgs.db.CarePlusDb;
import careplus.zsgs.dto.Doctors;

class ManageDoctorModel {
	
	private ManageDoctorView view;
	ManageDoctorModel(ManageDoctorView view)
	{
		this.view=view;
	}
	

	

}
