package careplus.zsgs.careplusSetupForReceptionist;

public class CarePlusSetUpModel {
	
	private CarePlusSetUpView view;
	
	CarePlusSetUpModel(CarePlusSetUpView view)
	{
		this.view=view;
	}

}
