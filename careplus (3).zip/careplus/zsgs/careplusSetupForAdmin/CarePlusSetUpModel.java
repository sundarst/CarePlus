package careplus.zsgs.careplusSetupForAdmin;

import java.util.List;

import careplus.zsgs.db.CarePlusDb;
import careplus.zsgs.dto.Appointment;

public class CarePlusSetUpModel {
	
	private CarePlusSetUpView view;
	
	CarePlusSetUpModel(CarePlusSetUpView view)
	{
		this.view=view;
	}

	
	
	
	
}
